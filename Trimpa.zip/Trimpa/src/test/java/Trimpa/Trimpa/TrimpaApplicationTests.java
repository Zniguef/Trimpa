package Trimpa.Trimpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrimpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
