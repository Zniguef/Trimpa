package Trimpa.Trimpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrimpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrimpaApplication.class, args);
	}

}
